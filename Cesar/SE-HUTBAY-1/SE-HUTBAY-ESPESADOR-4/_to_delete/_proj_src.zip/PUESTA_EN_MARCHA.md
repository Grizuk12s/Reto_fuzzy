# Puesta en marcha — SE HUTBAY

Guía operativa para dejar el Sistema Experto funcionando en una planta nueva.

El producto viene como **plantilla estándar** (control de espesador) y se moldea al
cliente: se cargan sus tags, se declaran sus variables y se escriben sus reglas.
Este documento es el orden en que hay que hacerlo.

> **Estado actual de esta instalación:** la plantilla del espesador está vaciada.
> Reglas, estados, waits, permisivos y tablas defuzzy están en blanco a la espera
> de la lógica que se defina en planta. Ver `CLAUDE.md` para el detalle.

---

## 0. Levantar el sistema

### Con Docker (lo normal en planta)

```bash
docker compose up -d --build
docker compose logs -f se-espesador
```

Queda en `http://<ip-del-host>:5000/`.

Al arrancar, el contenedor ejecuta `scripts/seed_tags_planta.py`, que siembra los
tags PCS7 en `config/espesador/tags.json` **sin pisar nada que ya hayas editado**.
Es idempotente: en reinicios no duplica. Para saltarlo: `SEED_TAGS_PLANTA=0`.

Como `./config` es un volumen, toda la configuración sobrevive a los reinicios y a
los rebuilds de la imagen.

### Sin Docker (desarrollo)

```bash
python -m venv .venv
.venv\Scripts\activate          # Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

### Verificar

```bash
curl http://localhost:5000/health          # {"status":"ok"}
```

---

## 1. Conectar el KEPserver

Página **Tags KEPserver**, panel *Conexión KEPserver*.

Host y puerto del servidor OPC-UA (por defecto `49320`), botón **Probar conexión**.
La URL efectiva se muestra bajo los campos.

> Dentro del contenedor, `host.docker.internal` apunta al host que corre Docker.
> Si el KEPserver está en otra máquina, se pone su IP directamente.

---

## 2. Cargar los tags

Los tags PCS7 ya vienen sembrados. Para agregar otros, el formulario superior de
**Tags KEPserver** pide tres cosas:

| Campo | Qué es |
|---|---|
| Nombre | Item ID exacto de KEPserver: `Canal.Dispositivo.Tag` |
| Tipo | Float, Int, Boolean o String |
| Categoría | Qué papel juega en el SE (ver abajo) |

### Las cinco categorías

| Categoría | Rol | Lo lee / escribe el SE |
|---|---|---|
| **PV** | Variable de proceso: se fuzzifica y alimenta las reglas | Lee |
| **CRUDA** | Sensor que no se fuzzifica; insumo de variables derivadas y permisivos | Lee |
| **LIM** | Límite `lmin`/`lmax` de una PV; da la escala a la fuzzificación | Lee |
| **SP** | Setpoint: la salida del experto | **Escribe** |
| **OTRO** | Handshake, heartbeat, selectores. No participa del pipeline | Solo monitoreo |

La categoría **no** se deduce del nombre del tag: se elige a mano. Eso permite
cualquier nomenclatura de planta.

### El pseudónimo importa más de lo que parece

El **identificador** de la variable dentro del SE se genera del pseudónimo del tag
(o del último segmento del nombre si no tiene) y **queda congelado**. Es lo que van
a ver las reglas, los filtros y los modelos difusos.

Por eso, antes de seguir:

- Dale a cada tag PV y SP un pseudónimo **claro y único**.
- Dos tags con el mismo pseudónimo generan el mismo identificador y se fundirían en
  una sola variable. El sistema avisa, pero conviene no llegar a eso.

Ejemplo de pseudónimos que dan problemas y su corrección:

| Tag | Pseudónimo malo | Pseudónimo bueno |
|---|---|---|
| `PU009_Velocidad_PV` | Velocidad | Velocidad PU-009 |
| `PU0026_Velocidad` | Velocidad | Velocidad PU-026 |
| `AG004_Nivel_PV_A` | Nivel (transmisor A) | Nivel TK004 A |

Editar el pseudónimo **después** de crear la variable es seguro: no rompe nada.
Cambiar el identificador ya creado sí tiene consecuencias, y por eso es una acción
aparte ("Renombrar") que muestra el impacto antes de aplicar.

---

## 3. Ver los datos moverse

### Lectura en vivo

En **Tags KEPserver**, panel *Lectura de Tags en Vivo*: botón **Iniciar lectura** y
un selector de refresco (500 ms a 10 s). Lee solo PV, CRUDA, LIM y SP — los OTRO no
se consultan. **Detener** congela los valores en pantalla.

### Simular valores (solo antes de tener el DCS real)

Panel *Generador de Datos para KEPserver*. Marca con el checkbox **Sim.** los tags
que quieras mover y pulsa Iniciar. Los desmarcados no se escriben nunca.

- Los tags nuevos aparecen aquí solos, **desactivados**, para no pisar por accidente
  una señal que ya viene de planta.
- Los tags LIM se configuran con un único campo **Valor fijo**: un límite no debe
  moverse.

> **En planta con el DCS conectado, el generador debe estar apagado.** Escribiría
> valores sintéticos encima de las señales reales de proceso.

Alternativa desde terminal, con dinámica más realista (seno lento + ruido):

```bash
docker compose exec se-espesador python scripts/simular_planta_kepserver.py --handshake
```

---

## 4. Declarar el contrato de variables

Página **Contrato de Variables**. Es la lista de variables que el experto reconoce;
todo lo demás se cuelga de ella.

1. Pulsa **Sincronizar con tags**. Propone PV y SP desde tus tags, muestra el impacto
   y, al confirmar, asigna solos los roles de los tags PV y SP.
2. Quita a mano las variables que este cliente no use.

### Regla práctica para decidir qué es PV

**Una PV necesita sus dos tags de límite.** Si una señal no tiene `MIN` y `MAX`, no
se puede fuzzificar: no la declares PV, pásala a CRUDA. Se sigue leyendo igual y
alimenta derivadas y permisivos.

Contar límites disponibles es la forma más rápida de saber cuántas PV soporta la
instrumentación entregada.

### Lo único que queda manual: los límites

Qué PV acota cada tag LIM no se puede deducir del nombre. Ese enlace se hace en
**Tags KEPserver**, columna *Rol en el SE*: al tag `Hopper_Lvl_MAX` se le asigna el
rol `nivel_hopper_lmax`.

> Después de guardar el contrato hay que **reiniciar la aplicación** para que el
> núcleo tome la nueva lista.

---

## 5. Configurar el pipeline

En este orden, porque cada paso depende del anterior.

### 5.1 Variables calculadas

Página **Variables calc.**

- *Variables de entrada (PV)*: botón **+ PV**, se eligen del catálogo, no se escriben.
- *Definiciones calculadas*: nombre libre, parámetros desde el desplegable. El orden
  importa — una definición puede referenciar otra anterior.

### 5.2 Filtros Exp-Q

Página **Filtros**. Botón **Sincronizar con tags PV**.

> **Toda PV necesita filtro.** Si llega una PV sin configurar, el tick falla. Las
> nuevas entran con `q=0.15, window_size=10`; se ajustan mirando crudo vs filtrado
> en la página de Traza.

Guía rápida: `q≈0.05` suaviza mucho con lag alto, `q≈0.15` es el balance, `q≈0.40`
casi no filtra.

### 5.3 Fuzzificación

Página **Fuzzificación**. Se elige una PV y **+ Crear fuzzy**, indicando el tipo:

| Tipo | Offset que mide | Cuándo usarlo |
|---|---|---|
| `high` | `lmax − pv` | Preocupa acercarse al máximo |
| `low` | `pv − lmin` | Preocupa acercarse al mínimo |
| `norm` | `(pv − lmin) / (lmax − lmin)` | Interesa la posición dentro del rango |

Nace con una plantilla neutra de 3 puntos. Se calibra ajustando el eje `offset` y
los grados de `HIGH`, `OK` y `LOW`, que van de 0 a 1.

### 5.4 Tracking PV-SP

Página **Tracking**. Botón **Sincronizar con tags SP**.

Por cada setpoint se elige un **readback** (la PV que mide el efecto real) y un
**rango** de tolerancia. Mientras `|PV − SP| > rango`, esa familia queda bloqueada y
el motor no emite más acciones sobre ella. Evita que el experto corrija más rápido
de lo que el proceso responde.

Sin readback, el tracking no bloquea nada.

### 5.5 Defuzzificación

Página **Defuzzificación**. Una tabla por familia de setpoint: **+ Crear familia**.

Las filas son **acciones con nombre libre** — el nombre es exactamente lo que las
reglas van a poner en su `then`. Las columnas son puntos del belief (0 a 1) y cada
celda es el incremento que se aplica al setpoint con ese belief.

Una misma acción no puede estar en dos familias: el motor no sabría qué setpoint
mover, y el sistema lo rechaza.

### 5.6 Estados, Waits, Permisivos y Reglas

- **Estados / Subestados**: agrupaciones de condiciones reutilizables.
- **Waits**: cooldowns que bloquean una acción durante N segundos tras dispararse.
- **Permisivos**: condiciones que habilitan o inhiben acciones. Es el lugar correcto
  para las protecciones (corriente alta, flujo de sello bajo).
- **Motor de Reglas**: las reglas IF/THEN.

Cada regla tiene cuatro partes:

| Parte | Qué hace |
|---|---|
| `if` | Condiciones en AND difuso (mínimo). Si da 0, la regla se descarta |
| `fuerza` | Condición que aporta la convicción, en OR (máximo) |
| `then` | Acciones, por nombre, que el defuzzy traduce a incrementos |
| waits | Cooldowns por acción |

Los **bloques** dan jerarquía: si dispara algo del bloque `crítico`, el de
`estabilidad` ni se evalúa.

---

## 6. Arrancar el SE

Página **Tags KEPserver**, panel *Sistema*: botón **Iniciar Sistema**.

El motor **se niega a arrancar con el mapeo incompleto** y te dice exactamente qué
falta. No es un error: correr con roles sin asignar produciría fuzzificación sobre
límites en 0 y reglas disparando sobre datos inventados.

Cada ciclo el motor: lee los tags → filtra → calcula derivadas → fuzzifica → evalúa
permisivos → evalúa reglas → defuzzifica → escribe los setpoints.

---

## 7. Verificar qué está pasando: la Traza

Página **Traza del Pipeline** (`/espesador/traza`). Es la herramienta principal de
diagnóstico. Muestra las nueve etapas del último tick con los números reales:

1. **Lectura** — cada tag con valor, quality y si falló
2. **Filtro** — crudo vs filtrado, para ver el lag que introduce
3. **Derivadas** — las variables calculadas
4. **Fuzzy** — valor, límites usados, dominio y grados de pertenencia
5. **Permisivos** — cuáles habilitaron y cuáles bloquearon
6. **Reglas** — **todas**, no solo las que dispararon, con el motivo de cada una
7. **Waits activos** — cuánto le falta a cada uno para liberar
8. **Defuzzy** — setpoint antes → después → delta
9. **Escritura** — qué se escribió o por qué no

La barra superior se corta en rojo en la etapa donde el tick abortó.

### La pregunta que contesta

*"No disparó nada, ¿por qué?"* — la etapa 6 lo dice regla por regla:

| Estado | Significado |
|---|---|
| `disparo` | Se aplicó |
| `descartada` | Activación en 0, belief bajo el mínimo, o wait activo |
| `no_evaluable` | Referencia variables que no existen en el estado fuzzy |
| `no_evaluada` | Un bloque más crítico ya disparó |

---

## Solución de problemas

| Síntoma | Causa habitual |
|---|---|
| Tags conectados pero en 0, sin moverse | Registros K del driver Simulator: son estáticos, alguien tiene que escribirlos. Usa el generador |
| "Iniciar Sistema" no hace nada | Mapeo incompleto — el motivo sale en rojo bajo el formulario |
| Tag "No existe" con quality Bad | El Item ID no coincide con KEPserver. Revisa el nombre carácter por carácter |
| La traza dice "Sin datos" | El motor no ha ejecutado ningún tick todavía |
| Una PV sin filtro | El tick falla. Sincroniza en la página de Filtros |
| Un SP sin tabla defuzzy | La acción sobre ese setpoint falla al aplicarse |
| Aviso "identificador en colisión" | Dos tags comparten pseudónimo. Corrige uno |

---

## Orden resumido

```
1. Conectar KEPserver
2. Cargar tags + categoría + pseudónimos únicos
3. Contrato de Variables → Sincronizar con tags
4. Tags KEPserver → asignar rol a los LIM (manual)
5. Variables calc. → entradas y derivadas
6. Filtros → Sincronizar
7. Fuzzificación → crear y calibrar
8. Tracking → Sincronizar y definir readbacks
9. Defuzzificación → crear familias y acciones
10. Estados, Waits, Permisivos, Reglas
11. Reiniciar la aplicación
12. Iniciar Sistema y verificar en la Traza
```
