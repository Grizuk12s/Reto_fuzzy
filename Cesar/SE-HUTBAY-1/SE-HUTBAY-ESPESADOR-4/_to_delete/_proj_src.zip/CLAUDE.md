# Contexto del proyecto — SE HUTBAY Espesador

Archivo de continuidad. Léelo antes de tocar nada: explica qué es el proyecto, en qué
estado quedó y qué está pendiente.

**Guía operativa completa:** `PUESTA_EN_MARCHA.md`

---

## Qué es

Sistema Experto difuso que lee variables de proceso desde **KEPserver vía OPC-UA**,
las evalúa con lógica fuzzy y escribe **setpoints** de vuelta al DCS. Interfaz web
Flask, empaquetado en Docker.

Nació como prototipo de **control de espesador** (9 PV: torque, bed_mass, bed_level,
densidad, etc.) y se está convirtiendo en un **producto estándar que se moldea a cada
cliente**. Ese es el hilo conductor de casi todo el trabajo reciente.

---

## Estado actual

### El contrato ya es el del cliente, no el del espesador

Se reemplazó la plantilla del espesador por el contrato de esta planta.

| Archivo | Estado |
|---|---|
| `contrato.json` | **11 PV + 1 SP (`sp_vel_bomba`) + `limites_sp`** |
| `tags.json` | 27 tags, pseudónimos únicos, roles asignados |
| `variables.json` | `crudas: {}` y `definiciones: []` — ya no hay crudas |
| `filtros.json` | 11 entradas, una por PV (`q=0.15`, `window_size=10`) |
| `fuzzy.json` | 11 entradas, plantilla `norm` neutra |
| `tracking.json` | 1 familia (`sp_vel_bomba`), deshabilitada |
| `reglas.json` | `[]` |
| `estados.json` | `{}` |
| `waits.json` | `[]` |
| `permisivos.json` | `{}` |
| `defuzzy.json` | `{}` |

> **"Vacío" es un estado válido.** Los loaders solo caen a la plantilla de Python si
> el archivo **falta o está corrupto**, no si está vacío.

### Reparto de los 27 tags

| Categoría | N | Detalle |
|---|---|---|
| PV | 11 | `nivel_hopper`, `velocidad_bomba` + las 9 que antes eran CRUDA |
| LIM | 6 | 4 asignados (hopper, velocidad); 2 de TK-004 **huérfanos** |
| SP | 1 | `PU009_Exp_Speed_Exp` → `sp_vel_bomba` |
| OTRO | 8 | Handshake del lazo experto |
| — | 1 | `PC02.OS_SERVER01_Velocidad`, tag de prueba, **deshabilitado** |

### Lo único que bloquea el arranque: 18 tags de límite

```
Mapeo de tags incompleto. LIM sin mapear: nivel_hopper_a_lmin, ... presion_pic2391_lmax
```

El núcleo exige `_lmin` y `_lmax` por cada PV del contrato. Con 11 PV hacen falta 22
límites y planta entregó 6. **Es un dato de planta, no de configuración**: todo el
resto del cableado ya está resuelto.

Detalle relevante si se quiere destrabar sin pedir tags: `catalogo_roles()` genera
ambos límites para toda PV y `faltantes` exige los dos, pero `evaluar_fuzzys` solo
usa ambos cuando el modelo es `norm`. Un modelo `low` usa solo `lmin` y uno `high`
solo `lmax`. El requisito es más estricto que lo que la lógica difusa necesita.

### Y aunque el mapeo se complete, el SE no decidirá nada

`reglas.json`, `defuzzy.json`, `permisivos.json`, `estados.json` y `waits.json` están
vacíos. El motor va a leer, filtrar y fuzzificar las 11 variables correctamente, y
después no disparar ninguna regla ni mover ningún setpoint. Esa es la lógica que
falta definir en planta.

---

## Arquitectura

```
KEPserver (OPC-UA)
      │  lee PV / LIM
      ▼
SEEngine  (web/state.py)  ── hilo en background, un tick cada N segundos
      │
      ├─ filtro Exp-Q          core/filters/exp_q.py   ← config de filtros.json
      ├─ fuzzificación         core/fuzzy/evaluator.py + templates.py ← fuzzy.json
      ├─ permisivos            core/engine/permisivos.py
      ├─ motor de reglas       core/engine/motor.py
      └─ defuzzificación       core/engine/defuzzy.py
      │
      ▼  escribe SP
KEPserver → DCS
```

> **Ojo con este diagrama:** el paso de *variables derivadas* NO existe en el motor
> en vivo. Ver "Hallazgos" más abajo.

### Mapa de archivos

| Ruta | Qué hay |
|---|---|
| `app.py` | Factory Flask, registra blueprints |
| `web/state.py` | `SEEngine`, generador, heartbeat, mapeo tag↔rol, traza |
| `web/api/tags.py` | CRUD de tags, generador, lectura en vivo, heartbeat |
| `web/api/config.py` | Filtros, fuzzy, defuzzy, tracking, variables, estados, waits, permisivos |
| `web/api/contrato.py` | Contrato de variables + límites de SP + análisis de impacto |
| `web/api/se.py` | Arranque/parada del motor, traza, alertas |
| `core/` | Núcleo genérico, sin nada específico del espesador |
| `processes/espesador/` | Definiciones del proceso (plantilla) |
| `connectors/kepserver.py` | Toda la lógica OPC-UA |
| `scripts/seed_tags_planta.py` | Siembra los tags PCS7 (corre en el arranque del contenedor) |
| `tests/test_pipeline.py` | 25 tests. Red de seguridad del cableado, no de la lógica difusa |

---

## Decisiones de diseño tomadas

### Tag ≠ variable: categoría + identificador

Un tag tiene **categoría** (PV, CRUDA, LIM, SP, OTRO) que se elige a mano. El
**identificador** de la variable se genera del pseudónimo y **queda congelado**: si
siguiera al pseudónimo, mejorar una etiqueta rompería en silencio todas las reglas
que la nombran.

### Fallar ruidoso, nunca adivinar

**El SE debe negarse a correr antes que correr sobre datos inventados.** `start()`
valida y reporta todo junto:

- mapeo tag↔rol incompleto
- PV sin config de filtro en `filtros.json`
- PV sin modelo difuso en `fuzzy.json`
- SP sin límites en `contrato.json`
- SP cuyo valor actual no se pudo leer del DCS

### Los límites de SP viven en el contrato

`limites_sp` en `contrato.json` es lo que clipea la escritura al DCS.
`apply_actions_tabla` solo recorre las familias presentes en ese dict: **un SP sin
límites no se clipea y se escribe sin tope.** Por eso el motor se niega a arrancar
así, y `_normalizar()` conserva el campo cuando el payload no lo trae (la UI todavía
no lo edita, y sin esa protección cualquier guardado lo borraría en silencio).

### Arranque bumpless

`_init_state()` lee del DCS el valor vigente de cada SP y parte de ahí. Si cae fuera
del rango declarado, entra al rango de una vez. Antes partía de `SETPOINTS_BASE`,
hardcodeado, y pisaba el setpoint del operador en el primer tick.

### Configuración sobre código

El contrato, los filtros, los modelos difusos y los límites de SP se leen de JSON.
Nada de eso debería volver al código.

---

## Hallazgos (verificados ejecutando, no leyendo)

### 1. Las variables derivadas no existen en el motor en vivo

`calcular_variables_df()` se llama **solo** en `runner.py:436`, el runner de CSV/batch.
`SEEngine._run_tick` nunca la llama: las definiciones de `variables.json` están
muertas en el camino online. El `tz["derivadas"]` de la traza es engañoso — solo
lista los `_lmin`/`_lmax` y los setpoints, no derivadas reales.

**Consecuencia práctica:** una PV no puede ser una variable calculada. Además de que
`construir_mapeo()` exige un tag por PV, el valor nunca se computaría.

### 2. `PEND_MODELOS` tumbaba el tick entero

`runner.py:355` iteraba los modelos de pendiente (hardcodeados con las variables del
espesador) haciendo `inputs[var]` directo → `KeyError: 'torque'` en **todos** los
ticks de cualquier contrato distinto. Se le puso un guard.

**No está resuelto el fondo:** `PEND_MODELOS` sigue hardcodeado en
`fuzzys_models_espesador.py` y sigue faltando el equivalente a `fuzzy.json` para las
pendientes. Una regla que use tendencias (`("pend_nivel_hopper", "NO-INC")`) quedará
`no_evaluable`; el motor lo explica en la traza.

### 3. Los tests estaban atados al contrato del espesador

El fixture generaba los tags desde el contrato vigente, pero los valores y las
aserciones estaban clavados a las 9 PV del espesador. Los tests solo pasaban mientras
el contrato fuera el original — se caían justo en la operación para la que existe el
producto. Ya derivan todo del contrato.

### 4. `start()` no devolvía nada en el camino feliz

`web/api/se.py:79` lo tapaba con `or {"ok": True}`, así que un arranque fallido podía
leerse como exitoso. Corregido.

---

## Pendientes conocidos

### 1. Pendientes fuzzy (`pend_<var>`) — sigue abierto

Ver Hallazgo 2. Falta la config editable y el constructor de registry, equivalente a
lo que se hizo con `fuzzy.json`.

### 2. Reloj del motor — sigue abierto

`self._t_s += self._intervalo_s` en `web/state.py` es un contador ficticio, no tiempo
real. Además el `wait(intervalo)` va después del trabajo, así que el período real es
`intervalo + duración del tick`. **Los waits de 900 s no duran 900 s.**

Arreglo: `t_s` desde `time.monotonic()` y sleep compensado.

### 3. Política de calidad de dato — sigue abierto

`_read_tags` aborta el tick entero si un PV falla. Falta: retener último valor bueno
con timeout, e **inhibir las reglas que dependen de una variable degradada**.

Relacionado: `connectors/kepserver.py` usa `get_value()`, que descarta el StatusCode
y el SourceTimestamp de OPC-UA. El campo `quality` que se muestra es inventado por el
código. Con `get_data_value()` se tendría calidad real y detección de congelados.

### 4. Arranque sin salto de setpoint — CERRADO

Ver "Arranque bumpless".

### 5. Escritura de SP sin control — sigue abierto

`_write_setpoints()` escribe el SP en cada tick aunque no cambie. Falta
write-on-change, límite de tasa por SP, y el interlock de habilitación.

El DCS ya provisionó el handshake completo (`PU009_Exp_Enable_Ext`, `Enable_FBK`,
`Exp_HB`, `LIC_Auto/Manual`, selectores). Debería ser **fail-closed**: si el enable no
se puede leer o tiene calidad mala, no se escribe.

### 6. `_save_tags` sin lock — sigue abierto

Read-modify-write sin sincronizar, llamado por el generador, el heartbeat y la API.
Ya se corrompieron datos una vez por esto.

### 7. Colisiones de pseudónimo — CERRADO

Los 27 tags tienen pseudónimo único, con el equipo en el nombre (PU-009, PU-0025,
AG-004, TK-004, PIC-2391).

---

## Cosas que quedaron sin confirmar

1. **¿AG-004 y TK-004 son el mismo estanque?** De eso depende si los límites
   `PU009_Exp_TK004_Lvl_MIN/MAX` acotan `nivel_ag004_a/b` o quedan huérfanos.
2. **¿AG-004 está aguas arriba o aguas abajo de la bomba?** Define el signo: si está
   aguas abajo, subir velocidad lo llena; si está aguas arriba, lo vacía.
3. **`limites_sp` de `sp_vel_bomba` quedó en `[20, 95]`**, heredado tal cual de
   `simulacion.LIMITES_SP`. No cambia el comportamiento anterior, pero **nadie
   confirmó que ese rango sea el correcto**. Contrastar con `PU009_Speed_MIN/MAX`.
4. **Los 11 modelos difusos son plantillas, no ingeniería.** Todos `norm` en dominio
   `[0, 0.5, 1]` con HIGH/OK/LOW simétricos. Hacen que el registry cargue; no
   describen ninguna variable real. Igual con `q=0.15` en los 11 filtros.
5. **`velocidad_bomba_sp_local` quedó como PV.** Es el setpoint del lazo local de la
   PU-009, no una medición: se va a fuzzificar y exige sus dos límites.
6. **`tracking.json` no está conectado al motor.** `tracking` solo aparece en
   `web/state.py:71` como constante de ruta y en la API; el `SEEngine` nunca lo lee.
7. `PU009_Corriente` no tiene límites: ¿cuáles son sus rangos de ingeniería?
8. El tag `PU009_Exp_Hesrt_Int` parece tener un dedazo ("Hesrt" por "Heart").

---

## Convenciones de trabajo

- **Verificar, no suponer.** Antes de afirmar algo del comportamiento, comprobarlo
  ejecutando código.
- **No adivinar mapeos de señal.** Asignar la señal equivocada a una variable no
  produce un error: produce un experto que controla mal en silencio.
- **Cambios aditivos en el núcleo.**
- **Correr los tests** después de cada cambio: `python -m pytest tests/ -q`
- **Validar el JS** de `index.html` tras editarlo — es un archivo grande y un error
  de sintaxis deja la página muerta sin aviso:
  ```bash
  python3 -c "import re;s=open('web/templates/index.html',encoding='utf-8').read();open('/tmp/x.js','w').write(max(re.findall(r'<script>(.*?)</script>',s,re.S),key=len))" && node --check /tmp/x.js
  ```

---

## Cómo se levanta

### Contenedor

```bash
docker compose up -d --build
docker compose logs -f se-espesador
```

Queda en `http://<ip-del-host>:5000/`. `./config` es un volumen, así que la
configuración sobrevive a rebuilds. El entrypoint siembra los tags PCS7 de forma
idempotente; se salta con `SEED_TAGS_PLANTA=0`.

**`workers = 1` es obligatorio** (`gunicorn.conf.py`): el `SEEngine` mantiene estado
en memoria del proceso y una única conexión OPC-UA. Con N workers habría N motores
compitiendo por los mismos tags.

### Sin Docker (desarrollo)

```bash
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

### Simulador de DCS (OPC-UA)

```bash
cd Simulador_DCS_OPC_UA
pip install -r requirements.txt
python dcs_opcua_server.py --host 0.0.0.0 --port 4840 --periodo 1.0
python test_client.py --handshake       # en otra consola
```

Endpoint `opc.tcp://<ip>:4840/dcs/`, seguridad None, anónimo. KEPserver se conecta a
él como **cliente** OPC-UA (driver "OPC UA Client", licencia aparte). Detalle completo
en `Simulador_DCS_OPC_UA/README.txt`.

---

## Documentación vieja

`README.txt` y `COMO_EJECUTAR.txt` describen el prototipo del espesador con tags
`RETO.*` y las 28 reglas. **Están desactualizados.** `PROJECT_CONTEXT.md` también.
`DESPLIEGUE_LINUX.txt` y `EXPORTAR_Y_DESPLEGAR.txt` siguen siendo válidos para la
parte de infraestructura.
