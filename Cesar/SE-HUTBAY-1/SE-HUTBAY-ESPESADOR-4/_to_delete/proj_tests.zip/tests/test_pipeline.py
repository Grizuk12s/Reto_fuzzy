# -*- coding: utf-8 -*-
"""Red de seguridad del pipeline del SE.

No prueba la logica difusa en si (eso es el nucleo y no se toca), sino que
el cableado alrededor se comporte igual antes y despues de los cambios:
mapeo tag<->rol, lectura, aborto por PV faltante y traza.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import copy
import pytest

import web.state as st


# ---------------------------------------------------------------
# Fixtures: KEPserver falso, sin red
# ---------------------------------------------------------------
def _tags_completos():
    """Un tags.json valido con los 36 roles del contrato mapeados."""
    from config import VARIABLES_PROCESO, VARIABLES_CRUDAS_REQUERIDAS, SETPOINT_KEYS
    tags, i = [], 1
    for v in VARIABLES_PROCESO:
        tags.append({"id": i, "name": f"PLANTA.PV_{v}", "data_type": "Float",
                     "enabled": True, "categoria": "pv", "rol": v}); i += 1
        for b in ("lmin", "lmax"):
            tags.append({"id": i, "name": f"PLANTA.LIM_{v}_{b}", "data_type": "Float",
                         "enabled": True, "categoria": "lim", "rol": f"{v}_{b}"}); i += 1
    for v in VARIABLES_CRUDAS_REQUERIDAS:
        tags.append({"id": i, "name": f"PLANTA.CR_{v}", "data_type": "Float",
                     "enabled": True, "categoria": "cruda", "rol": v}); i += 1
    for k in SETPOINT_KEYS:
        tags.append({"id": i, "name": f"PLANTA.SP_{k}", "data_type": "Float",
                     "enabled": True, "categoria": "sp", "rol": k}); i += 1
    return tags


def _valores_sinteticos():
    """Valores y limites de prueba para las PV del contrato VIGENTE.

    Antes esto era un dict fijo con las 9 PV del espesador, asi que la red de
    seguridad se caia entera en cuanto se moldeaba el contrato a otro cliente
    — justo la operacion que el producto existe para soportar. Se genera a
    escala 0-100 con la PV a media escala: el cableado no depende del valor.
    """
    from config import VARIABLES_PROCESO
    return ({v: 50.0 for v in VARIABLES_PROCESO},
            {v: (0.0, 100.0) for v in VARIABLES_PROCESO})


VALORES, LIMS = _valores_sinteticos()


@pytest.fixture
def kep(monkeypatch):
    """Sustituye la lectura OPC-UA por valores fijos. `omitir` simula tags caidos."""
    estado = {"omitir": set(), "escrituras": [], "sp_en_dcs": 42.0}

    def _read(nombres):
        out = {}
        for n in nombres:
            if n in estado["omitir"]:
                out[n] = {"connected": True, "exists": False, "value": None, "quality": "Bad"}
                continue
            val = 0.0
            if n.startswith("PLANTA.PV_"):
                val = VALORES[n[len("PLANTA.PV_"):]]
            elif n.startswith("PLANTA.LIM_"):
                rol = n[len("PLANTA.LIM_"):]
                var, bound = rol.rsplit("_", 1)
                val = LIMS[var][0 if bound == "lmin" else 1]
            elif n.startswith("PLANTA.CR_"):
                val = 100.0
            elif n.startswith("PLANTA.SP_"):
                val = estado["sp_en_dcs"]
            out[n] = {"connected": True, "exists": True, "value": val, "quality": "Good"}
        return out

    monkeypatch.setattr(st, "_read_kepserver_tags_batch", _read)
    monkeypatch.setattr(st._kep, "write_float_batch",
                        lambda vals: estado["escrituras"].append(dict(vals)))
    monkeypatch.setattr(st, "_license_check",
                        lambda: {"valid": True, "reason": "", "expires_at": None})
    return estado


@pytest.fixture
def config_completa(monkeypatch):
    """filtros.json, fuzzy.json y limites de SP alineados al contrato vigente.

    El motor se niega a arrancar si a una PV le falta filtro o modelo difuso,
    o si a un SP le faltan limites; estas piezas son las que lo dejan correr.
    """
    from config import VARIABLES_PROCESO, SETPOINT_KEYS
    import runner, config as cfg

    monkeypatch.setattr(runner, "cargar_filtros_json",
                        lambda path=None: {v: {"q": 0.15, "ventana_s": 50.0}
                                           for v in VARIABLES_PROCESO})
    monkeypatch.setattr(cfg, "LIMITES_SP_CONTRATO",
                        {k: (0.0, 100.0) for k in SETPOINT_KEYS})
    monkeypatch.setattr(runner, "cargar_fuzzy_json",
                        lambda path=None: {
                            v: {"type": "norm", "offset": [0.0, 0.5, 1.0],
                                "labels": {"HIGH": [1.0, 0.5, 0.0],
                                           "OK":   [0.0, 1.0, 0.0],
                                           "LOW":  [0.0, 0.5, 1.0]}}
                            for v in VARIABLES_PROCESO})
    return True


@pytest.fixture
def store(monkeypatch):
    datos = {"tags": _tags_completos(), "next_id": 999}
    monkeypatch.setattr(st, "_load_tags", lambda: copy.deepcopy(datos))
    monkeypatch.setattr(st, "_save_tags", lambda d: None)
    return datos


# ---------------------------------------------------------------
# Mapeo
# ---------------------------------------------------------------
def test_mapeo_completo_con_nombres_de_planta(store):
    """El mapeo funciona con nomenclatura arbitraria, no solo RETO.*"""
    from config import VARIABLES_PROCESO, SETPOINT_KEYS
    m = st.construir_mapeo()
    assert m["listo"] is True
    assert m["duplicados"] == {}
    # Los tamanos salen del contrato vigente, no de un numero fijo.
    assert len(m["tag_to_pv"]) == len(VARIABLES_PROCESO)
    assert len(m["tag_to_lim"]) == 2 * len(VARIABLES_PROCESO)
    sp0 = SETPOINT_KEYS[0]
    assert m["sp_to_tag"][sp0] == f"PLANTA.SP_{sp0}"
    pv0 = VARIABLES_PROCESO[0]
    assert m["tag_to_pv"][f"PLANTA.PV_{pv0}"] == pv0


def test_mapeo_detecta_rol_faltante(store):
    from config import VARIABLES_PROCESO
    victima = VARIABLES_PROCESO[0]
    store["tags"] = [t for t in store["tags"] if t["rol"] != victima]
    m = st.construir_mapeo()
    assert m["listo"] is False
    assert victima in m["faltantes"]["pv"]


def test_mapeo_ignora_tags_suspendidos(store):
    from config import VARIABLES_PROCESO
    victima = VARIABLES_PROCESO[-1]
    for t in store["tags"]:
        if t["rol"] == victima and t["categoria"] == "pv":
            t["enabled"] = False
    m = st.construir_mapeo()
    assert victima in m["faltantes"]["pv"]
    assert m["listo"] is False


def test_cruda_faltante_no_bloquea_arranque(store):
    """Las CRUDA degradan los permisivos pero no impiden arrancar.

    El contrato de crudas es configurable y puede estar vacio; en ese caso
    no hay nada que probar aqui.
    """
    from config import VARIABLES_CRUDAS_REQUERIDAS
    if not VARIABLES_CRUDAS_REQUERIDAS:
        pytest.skip("El contrato vigente no define variables crudas.")
    victima = VARIABLES_CRUDAS_REQUERIDAS[0]
    store["tags"] = [t for t in store["tags"] if t["rol"] != victima]
    m = st.construir_mapeo()
    assert victima in m["faltantes"]["cruda"]
    assert m["listo"] is True


def test_motor_no_arranca_con_mapeo_incompleto(store, kep):
    from config import VARIABLES_PROCESO
    victima = VARIABLES_PROCESO[0]
    store["tags"] = [t for t in store["tags"] if t["rol"] != victima]
    eng = st.SEEngine()
    res = eng.start(intervalo_s=1)
    assert res["ok"] is False
    assert victima in res["error"]
    assert eng._running is False


# ---------------------------------------------------------------
# Pipeline completo
# ---------------------------------------------------------------
def _tick(monkeypatch):
    """Corre un tick sin arrancar el hilo ni tocar Postgres."""
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._intervalo_s = 5.0
    eng._init_state()
    eng._run_tick()
    return eng


def test_tick_completo_produce_setpoints(store, kep, config_completa, monkeypatch):
    from config import SETPOINT_KEYS
    st._reset_trazas()
    eng = _tick(monkeypatch)
    assert eng._last_error is None
    assert set(eng._setpoints) == set(SETPOINT_KEYS), (
        "los setpoints del motor deben salir del contrato, no de una lista fija")
    assert kep["escrituras"], "debio escribir los SP al KEPserver"
    assert set(kep["escrituras"][-1]) == {f"PLANTA.SP_{k}" for k in SETPOINT_KEYS}


def test_setpoints_respetan_limites(store, kep, config_completa, monkeypatch):
    eng = _tick(monkeypatch)
    for k, v in eng._setpoints.items():
        lo, hi = eng._limites_sp[k]
        assert lo <= v <= hi, f"{k}={v} fuera de [{lo},{hi}]"


def test_pv_caido_aborta_el_tick_sin_escribir(store, kep, config_completa, monkeypatch):
    from config import VARIABLES_PROCESO
    victima = VARIABLES_PROCESO[0]
    st._reset_trazas()
    kep["omitir"].add(f"PLANTA.PV_{victima}")
    eng = _tick(monkeypatch)
    assert kep["escrituras"] == []
    assert victima in (eng._last_error or "")
    tz = st._get_trazas(1)[0]
    assert tz["abortado_en"] == "lectura"
    assert any(f["rol"] == victima for f in tz["lectura"] if not f["ok"])


# ---------------------------------------------------------------
# Traza
# ---------------------------------------------------------------
def test_traza_registra_todas_las_etapas(store, kep, config_completa, monkeypatch):
    st._reset_trazas()
    _tick(monkeypatch)
    tz = st._get_trazas(1)[0]
    assert tz["abortado_en"] is None
    # El tamano depende del contrato vigente, no de un numero fijo.
    cat = st.catalogo_roles()
    esperado = len(cat["pv"]) + len(cat["lim"]) + len(cat["cruda"])
    assert len(tz["lectura"]) == esperado
    assert len(tz["filtro"]) == len(cat["pv"])
    assert tz["fuzzy"], "debe haber estado fuzzy"
    # El set de reglas es configurable y puede estar vacio; si hay reglas,
    # la traza debe reportar el desenlace de todas.
    from runner import cargar_reglas_json
    assert len(tz["reglas"]) == len(cargar_reglas_json())
    assert len(tz["defuzzy"]) == len(cat["sp"])
    assert tz["cobertura"]["listo"] is True


def test_traza_explica_por_que_no_disparo_cada_regla(store, kep, config_completa, monkeypatch):
    st._reset_trazas()
    _tick(monkeypatch)
    tz = st._get_trazas(1)[0]
    estados = {r["estado"] for r in tz["reglas"]}
    assert estados <= {"disparo", "descartada", "no_evaluable", "no_evaluada"}
    for r in tz["reglas"]:
        assert r["motivo"], f"la regla {r['id']} no explica su desenlace"


def test_buffer_de_traza_es_circular(store, kep, config_completa, monkeypatch):
    st._reset_trazas()
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()
    for _ in range(st._TRAZA_SIZE + 10):
        eng._run_tick()
    assert len(st._get_trazas(0)) == st._TRAZA_SIZE


# ---------------------------------------------------------------
# El reporte del motor no altera decisiones (invariante critica)
# ---------------------------------------------------------------
def test_reporte_no_cambia_el_resultado_del_motor():
    from core.engine.motor import _evaluar_set_reglas
    from runner import cargar_reglas_json
    reglas = cargar_reglas_json()
    fuzzy = {"torque": {"pert": {"HIGH": 0.9, "NORMAL": 0.1}},
             "bed_level": {"pert": {"LOW": 0.8}},
             "densidad": {"pert": {"LOW": 0.7}}}

    sin = _evaluar_set_reglas(reglas, fuzzy, 0.0, {}, 0.05, reporte=None)
    con = _evaluar_set_reglas(reglas, fuzzy, 0.0, {}, 0.05, reporte=[])
    assert [f["id"] for f in sin] == [f["id"] for f in con]


# ---------------------------------------------------------------
# Contrato de variables (editable por cliente)
# ---------------------------------------------------------------
def test_contrato_cae_a_defaults_si_no_existe(tmp_path, monkeypatch):
    """Sin contrato.json el sistema arranca con la plantilla estandar."""
    import config as cfg
    monkeypatch.setattr(cfg, "CONTRATO_JSON", str(tmp_path / "no_existe.json"))
    pv, sp = cfg._cargar_contrato()
    assert pv == cfg.VARIABLES_PROCESO_DEFAULT
    assert sp == cfg.SETPOINT_KEYS_DEFAULT


def test_contrato_ignora_json_corrupto(tmp_path, monkeypatch):
    import config as cfg
    malo = tmp_path / "contrato.json"
    malo.write_text("{ esto no es json", encoding="utf-8")
    monkeypatch.setattr(cfg, "CONTRATO_JSON", str(malo))
    pv, sp = cfg._cargar_contrato()
    assert pv == cfg.VARIABLES_PROCESO_DEFAULT


def test_contrato_deduplica_y_limpia(tmp_path, monkeypatch):
    import config as cfg, json as _j
    p = tmp_path / "contrato.json"
    p.write_text(_j.dumps({
        "variables_proceso": ["torque", "torque", "  bed_level  ", "", None, 5],
        "setpoints": ["sp_vel_bomba"],
    }), encoding="utf-8")
    monkeypatch.setattr(cfg, "CONTRATO_JSON", str(p))
    pv, sp = cfg._cargar_contrato()
    assert pv == ["torque", "bed_level"]
    assert sp == ["sp_vel_bomba"]


def test_impacto_detecta_reglas_afectadas():
    """Quitar una variable debe reportar las reglas que la nombran."""
    from web.api.contrato import analizar_impacto, contrato_vigente
    from core.engine.motor import variables_de_regla
    from runner import cargar_reglas_json
    reglas = cargar_reglas_json()
    if not any("bed_level" in variables_de_regla(r) for r in reglas):
        pytest.skip("El set de reglas vigente no usa bed_level.")
    actual = contrato_vigente()
    nuevo = {
        "variables_proceso": [v for v in actual["variables_proceso"] if v != "bed_level"],
        "setpoints": list(actual["setpoints"]),
    }
    imp = analizar_impacto(nuevo)
    assert imp["requiere_confirmacion"] is True
    quitada = next(q for q in imp["quitadas"] if q["variable"] == "bed_level")
    assert quitada["reglas"], "bed_level aparece en reglas; debe reportarlas"


def test_impacto_avisa_piezas_faltantes_al_agregar():
    """Una PV nueva sin modelo difuso ni filtro no se puede evaluar."""
    from web.api.contrato import analizar_impacto, contrato_vigente
    actual = contrato_vigente()
    # Un nombre que no puede existir en ningun contrato real, para que el test
    # no dependa de cual sea el contrato vigente.
    nueva = "pv_inexistente_de_prueba"
    nuevo = {
        "variables_proceso": actual["variables_proceso"] + [nueva],
        "setpoints": list(actual["setpoints"]),
    }
    imp = analizar_impacto(nuevo)
    falta = next(f for f in imp["faltantes_nuevas"] if f["variable"] == nueva)
    assert any("difuso" in x for x in falta["falta"])
    assert any("filtro" in x for x in falta["falta"])


def test_contrato_rechaza_nombres_invalidos():
    from web.api.contrato import _normalizar
    for malo in ["Bed Level", "9var", "t_s", ""]:
        norm, err = _normalizar({"variables_proceso": [malo], "setpoints": ["sp_x"]})
        assert err is not None, f"'{malo}' deberia rechazarse"


def test_contrato_rechaza_pv_que_tambien_es_sp():
    from web.api.contrato import _normalizar
    norm, err = _normalizar({"variables_proceso": ["torque"], "setpoints": ["torque"]})
    assert err is not None and "PV y SP" in err


# ---------------------------------------------------------------
# Fugas del espesador en el motor en vivo
# ---------------------------------------------------------------
def test_filtro_sale_de_filtros_json_no_del_default(store, kep, config_completa,
                                                    monkeypatch):
    """El filtro Exp-Q debe configurarse con las PV del contrato.

    Con el default hardcodeado del espesador, ExpQFilter.actualizar() lanzaba
    KeyError en todos los ticks de cualquier contrato distinto.
    """
    from config import VARIABLES_PROCESO
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()
    assert eng._filtro is not None
    assert set(eng._filtro._config) == set(VARIABLES_PROCESO)


def test_no_arranca_si_una_pv_no_tiene_filtro(store, kep, config_completa,
                                              monkeypatch):
    import runner
    from config import VARIABLES_PROCESO
    huerfana = VARIABLES_PROCESO[0]
    monkeypatch.setattr(runner, "cargar_filtros_json",
                        lambda path=None: {v: {"q": 0.15, "ventana_s": 50.0}
                                           for v in VARIABLES_PROCESO
                                           if v != huerfana})
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    res = st.SEEngine().start(intervalo_s=1)
    assert res["ok"] is False
    assert huerfana in res["error"]


def test_no_arranca_si_un_sp_no_tiene_limites(store, kep, config_completa,
                                              monkeypatch):
    """Un SP sin limites no se clipea: se escribiria al DCS sin tope."""
    import config as cfg
    from config import SETPOINT_KEYS
    monkeypatch.setattr(cfg, "LIMITES_SP_CONTRATO", {})
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    res = st.SEEngine().start(intervalo_s=1)
    assert res["ok"] is False
    assert SETPOINT_KEYS[0] in res["error"]
    assert "sin limites" in res["error"]


def test_no_arranca_si_una_pv_no_tiene_modelo_difuso(store, kep, config_completa,
                                                     monkeypatch):
    """Sin modelo, evaluar_fuzzys se salta la variable en silencio."""
    import runner
    monkeypatch.setattr(runner, "cargar_fuzzy_json", lambda path=None: {})
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    res = st.SEEngine().start(intervalo_s=1)
    assert res["ok"] is False
    assert "modelo difuso" in res["error"]


def test_arranque_bumpless_parte_del_sp_del_dcs(store, kep, config_completa,
                                                monkeypatch):
    """No debe pisar el setpoint que el operador tiene puesto."""
    from config import SETPOINT_KEYS
    kep["sp_en_dcs"] = 37.5
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()
    for k in SETPOINT_KEYS:
        assert eng._setpoints[k] == 37.5


def test_start_devuelve_dict_al_arrancar_bien(store, kep, config_completa,
                                              monkeypatch):
    """start() no devolvia nada en el camino feliz."""
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    try:
        res = eng.start(intervalo_s=1)
        assert res == {"ok": True, "error": None}
        assert eng._running is True
    finally:
        eng.stop()


# ===============================================================
# Ciclo libre, reloj real y write-on-change
# ===============================================================

def test_t_s_es_reloj_real_y_no_un_contador_de_ticks(store, kep, config_completa,
                                                     monkeypatch):
    """`t_s` debe medir segundos, no ticks.

    Antes era `self._t_s += self._intervalo_s`: avanzaba 5.0 por vuelta sin
    importar cuanto habia tardado. Eso hacia que un wait de 900 s no durara
    900 s y que la ventana de pendientes no midiera 60 s.
    """
    import time
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()

    eng._run_tick()
    t1 = eng._t_s
    time.sleep(0.25)
    eng._run_tick()
    t2 = eng._t_s

    # Dos ticks seguidos: el reloj avanza lo que paso de verdad (~0.25 s),
    # no un intervalo nominal.
    assert 0.2 < (t2 - t1) < 0.6
    assert t1 >= 0.0


def test_el_lazo_no_espera_entre_ticks(store, kep, config_completa, monkeypatch):
    """Con piso 0 el motor debe iterar muchas veces en poco tiempo."""
    import time
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    try:
        assert eng.start(piso_s=0.0)["ok"] is True
        time.sleep(0.5)
        ticks = eng._tick
    finally:
        eng.stop()
    # Con el wait fijo de 5 s esto daba 1 tick. En ciclo libre son cientos.
    assert ticks > 20, f"solo {ticks} ticks en 0,5 s: el lazo sigue esperando"


def test_el_piso_acota_la_velocidad_del_lazo(store, kep, config_completa, monkeypatch):
    """El piso es un periodo MINIMO: limita los ticks, no los elimina."""
    import time
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    try:
        assert eng.start(piso_s=0.1)["ok"] is True
        time.sleep(0.6)
        ticks = eng._tick
    finally:
        eng.stop()
    assert 2 <= ticks <= 9, f"{ticks} ticks en 0,6 s con piso de 0,1 s"


def test_setpoint_se_escribe_solo_cuando_cambia(store, kep, config_completa,
                                                monkeypatch):
    """Write-on-change: sin reglas el SP no se mueve y no hay que reescribirlo."""
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()

    eng._run_tick()
    assert len(kep["escrituras"]) == 1, "el primer tick debe alinear el DCS"

    for _ in range(5):
        eng._run_tick()
    assert len(kep["escrituras"]) == 1, "sin cambio de SP no se debe reescribir"
    assert eng._sp_omitidos >= 5


def test_setpoint_cambiado_vuelve_a_escribirse(store, kep, config_completa,
                                               monkeypatch):
    """El deadband no debe bloquear un cambio real."""
    from config import SETPOINT_KEYS
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()
    eng._run_tick()
    n = len(kep["escrituras"])

    eng._setpoints[SETPOINT_KEYS[0]] += 3.0
    eng._run_tick()
    assert len(kep["escrituras"]) == n + 1


def test_escritura_fallida_se_reintenta(store, kep, config_completa, monkeypatch):
    """Si el write falla, el SP NO debe quedar marcado como escrito."""
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    eng = st.SEEngine()
    eng._init_state()

    def _explota(vals):
        raise RuntimeError("KEP caido")

    monkeypatch.setattr(st._kep, "write_float_batch", _explota)
    eng._run_tick()
    assert eng._sp_escritos == {}, "un write fallido no debe marcar el SP como escrito"

    monkeypatch.setattr(st._kep, "write_float_batch",
                        lambda vals: kep["escrituras"].append(dict(vals)))
    eng._run_tick()
    assert len(kep["escrituras"]) == 1, "el tick siguiente debe reintentar"


def test_traza_distingue_sin_cambio_de_error(store, kep, config_completa, monkeypatch):
    """Un tick sin escrituras es sano, no un fallo: la traza debe decirlo."""
    monkeypatch.setattr(st, "_alerts", st.AlertCollector())
    st._reset_trazas()
    eng = st.SEEngine()
    eng._init_state()
    eng._run_tick()
    eng._run_tick()

    tz = st._get_trazas(1)[0]
    assert tz["escritura"]["error"] is None
    assert tz["escritura"]["escritos"] == []
    assert tz["escritura"]["sin_cambio"]


def test_historial_de_tags_se_decima_por_tiempo(monkeypatch):
    """El ring buffer es de observabilidad: debe cubrir tiempo, no ticks."""
    st._tag_history.clear()
    for _ in range(500):                      # 500 vueltas en microsegundos
        st._record_tag_values({"PLANTA.SP_x": 1.0})
    guardadas = len(st._tag_history["PLANTA.SP_x"])
    assert guardadas == 1, (
        f"{guardadas} muestras guardadas: sin decimacion el Explorador de "
        "Series pierde su ventana de horas en minutos")


# ===============================================================
# Decimacion de la persistencia
# ===============================================================

@pytest.fixture
def pg(monkeypatch, tmp_path):
    """PostgreSQL falso: cuenta INSERTs sin tocar una base real."""
    import web.api.postgres as pgmod

    estado = {"inserts": 0, "filas": 0}

    class _Cur:
        def execute(self, *a, **k): pass
        def close(self): pass

    class _Conn:
        def cursor(self): return _Cur()
        def close(self): pass

    def _execute_values(cur, sql, records):
        estado["inserts"] += 1
        estado["filas"] += len(records)

    # psycopg2 esta en requirements.txt, pero un entorno de desarrollo minimo
    # puede no tenerlo: se salta en vez de fallar.
    _ex = pytest.importorskip("psycopg2.extras")
    monkeypatch.setattr(_ex, "execute_values", _execute_values)
    monkeypatch.setattr(pgmod, "_connect", lambda: _Conn())

    cfg = tmp_path / "postgres.json"
    cfg.write_text('{"database":"d","user":"u","persist_enabled":true,'
                   '"persist_periodo_ms":1000}', encoding="utf-8")
    monkeypatch.setattr(pgmod, "POSTGRES_JSON", str(cfg))
    monkeypatch.setattr(pgmod, "_cfg_cache", None, raising=False)
    monkeypatch.setattr(pgmod, "_cfg_cache_mtime", -1.0, raising=False)
    monkeypatch.setattr(pgmod, "_persist_last_t", 0.0, raising=False)
    for k in pgmod._persist_stats:
        pgmod._persist_stats[k] = 0 if isinstance(pgmod._persist_stats[k], int) else None
    return estado


def test_persistencia_se_decima_por_periodo(pg):
    """El motor llama en cada tick; la BD debe recibir un fotograma por periodo."""
    import web.api.postgres as pgmod
    entrada = {f"t{i}": 1.0 for i in range(27)}

    escritos = sum(pgmod.persist_tick(entrada, {"sp": 1.0}, {}, "espesadores")
                   for _ in range(300))

    assert escritos == 1, (
        f"{escritos} escrituras en 300 ticks: sin decimacion la base recibe "
        "una insercion por vuelta del ciclo libre")
    assert pgmod._persist_stats["ticks_omitidos"] == 299


def test_persistencia_forzada_ignora_el_periodo(pg):
    """La validacion de la pagina necesita escribir en el momento."""
    import web.api.postgres as pgmod
    assert pgmod.persist_tick({"t": 1.0}, {}, {}, "espesadores", forzar=True) is True
    assert pgmod.persist_tick({"t": 1.0}, {}, {}, "espesadores", forzar=True) is True


def test_persistencia_deshabilitada_no_escribe(pg, monkeypatch):
    import web.api.postgres as pgmod
    import json, os
    cfg = json.load(open(pgmod.POSTGRES_JSON, encoding="utf-8"))
    cfg["persist_enabled"] = False
    pgmod._save_pg_config(cfg)
    assert pgmod.persist_tick({"t": 1.0}, {}, {}, "espesadores") is False
    assert pg["inserts"] == 0


def test_estado_persistencia_reporta_sin_datos_al_inicio(pg):
    import web.api.postgres as pgmod
    est = pgmod.estado_persistencia()
    assert est["salud"] == "sin_datos"
    assert est["periodo_ms"] == 1000
    assert est["periodos_disponibles"] == [500, 1000]


# ===============================================================
# Fuzzy con etiquetas libres (filas creables / renombrables / borrables)
# ===============================================================

@pytest.fixture
def cfg_dir(monkeypatch, tmp_path):
    """Apunta fuzzy.json y reglas.json a un directorio temporal."""
    import web.state as _st
    import web.api.config as cfgmod
    fz = tmp_path / "fuzzy.json"
    rg = tmp_path / "reglas.json"
    rg.write_text("[]", encoding="utf-8")
    monkeypatch.setattr(_st, "FUZZY_JSON", str(fz))
    monkeypatch.setattr(cfgmod, "FUZZY_JSON", str(fz))
    monkeypatch.setattr(_st, "REGLAS_JSON", str(rg))
    monkeypatch.setattr(cfgmod, "REGLAS_JSON", str(rg))
    return {"fuzzy": fz, "reglas": rg}


def test_registry_acepta_etiquetas_arbitrarias():
    """El motor debe construirse con las filas que el operador defina."""
    from core.fuzzy.templates import construir_registry_fuzzy
    reg = construir_registry_fuzzy({
        "nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                  "labels": {"CRITICO_ALTO": [1.0, 0.2, 0.0],
                             "NORMAL":       [0.0, 1.0, 0.0],
                             "BAJO":         [0.0, 0.2, 1.0],
                             "MUY_BAJO":     [0.0, 0.0, 1.0]}}})
    assert "nivel" in reg
    modelo = reg["nivel"]["model"]
    assert set(modelo.conjuntos) == {"CRITICO_ALTO", "NORMAL", "BAJO", "MUY_BAJO"}
    # norm: off = (pv - lmin)/(lmax - lmin). Con pv=0 el offset es 0, donde
    # CRITICO_ALTO vale 1.0 y es la dominante.
    dominante, val, off, pert = modelo.evaluar(0.0, 0.0, 1.0)
    assert dominante == "CRITICO_ALTO"
    assert set(pert) == {"CRITICO_ALTO", "NORMAL", "BAJO", "MUY_BAJO"}


def test_registry_acepta_dos_etiquetas():
    """Nada obliga a que sean tres filas."""
    from core.fuzzy.templates import construir_registry_fuzzy
    reg = construir_registry_fuzzy({
        "v": {"type": "high", "offset": [0.0, 1.0, 2.0],
              "labels": {"ALTO": [1.0, 0.5, 0.0], "BAJO": [0.0, 0.5, 1.0]}}})
    assert set(reg["v"]["model"].conjuntos) == {"ALTO", "BAJO"}


def test_validador_acepta_etiquetas_libres():
    import web.api.config as cfgmod
    spec, err = cfgmod._validar_fuzzy_spec("v", {
        "type": "norm", "offset": [0.0, 0.5, 1.0],
        "labels": {"critico_alto": [1.0, 0.0, 0.0], "NORMAL": [0.0, 1.0, 0.0]}})
    assert err is None
    # Se normalizan a mayusculas: las reglas las nombran asi.
    assert set(spec["labels"]) == {"CRITICO_ALTO", "NORMAL"}


@pytest.mark.parametrize("etiqueta,motivo", [
    ("NO-ALTO",    "NO-"),
    ("CERCA_ALTO", "reservada"),
    ("ON",         "reservada"),
    ("2ALTO",      "invalido"),
    ("con espacio", "invalido"),
])
def test_validador_rechaza_etiquetas_que_pisan_al_nucleo(etiqueta, motivo):
    import web.api.config as cfgmod
    _, err = cfgmod._validar_fuzzy_spec("v", {
        "type": "norm", "offset": [0.0, 0.5, 1.0],
        "labels": {etiqueta: [1.0, 0.0, 0.0]}})
    assert err is not None, f"'{etiqueta}' deberia rechazarse"


def test_validador_rechaza_fuzzy_sin_etiquetas():
    import web.api.config as cfgmod
    _, err = cfgmod._validar_fuzzy_spec("v", {
        "type": "norm", "offset": [0.0, 0.5, 1.0], "labels": {}})
    assert err is not None and "al menos una" in err


def test_no_se_puede_borrar_una_etiqueta_que_una_regla_usa(cfg_dir):
    """Fallar ruidoso: borrar la fila deja la regla muerta."""
    import json
    import web.api.config as cfgmod

    cfg_dir["fuzzy"].write_text(json.dumps({
        "nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                  "labels": {"HIGH": [1.0, 0.5, 0.0], "OK": [0.0, 1.0, 0.0],
                             "LOW": [0.0, 0.5, 1.0]}}}), encoding="utf-8")
    cfg_dir["reglas"].write_text(json.dumps([
        {"id": "R1", "bloque": "critico", "if": [["nivel", "OK"]], "then": []}]),
        encoding="utf-8")

    nuevo = {"nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                       "labels": {"HIGH": [1.0, 0.5, 0.0], "LOW": [0.0, 0.5, 1.0]}}}
    problemas = cfgmod._huerfanas_por_guardar(cfgmod._load_fuzzy(), nuevo)
    assert problemas and "nivel.OK" in problemas[0] and "R1" in problemas[0]


def test_renombrar_una_etiqueta_usada_tambien_se_bloquea(cfg_dir):
    """Desde el JSON, renombrar es borrar + dar de alta."""
    import json
    import web.api.config as cfgmod

    cfg_dir["fuzzy"].write_text(json.dumps({
        "nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                  "labels": {"OK": [0.0, 1.0, 0.0]}}}), encoding="utf-8")
    cfg_dir["reglas"].write_text(json.dumps([
        {"id": "R7", "bloque": "critico", "if": [["nivel", "OK"]], "then": []}]),
        encoding="utf-8")

    nuevo = {"nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                       "labels": {"NORMAL": [0.0, 1.0, 0.0]}}}
    problemas = cfgmod._huerfanas_por_guardar(cfgmod._load_fuzzy(), nuevo)
    assert problemas and "R7" in problemas[0]


def test_una_etiqueta_sin_reglas_se_puede_borrar(cfg_dir):
    import json
    import web.api.config as cfgmod
    cfg_dir["fuzzy"].write_text(json.dumps({
        "nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                  "labels": {"OK": [0.0, 1.0, 0.0], "ALTO": [1.0, 0.0, 0.0]}}}),
        encoding="utf-8")
    nuevo = {"nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                       "labels": {"OK": [0.0, 1.0, 0.0]}}}
    assert cfgmod._huerfanas_por_guardar(cfgmod._load_fuzzy(), nuevo) == []


def test_el_catalogo_de_etiquetas_incluye_las_filas_del_fuzzy(cfg_dir):
    """Sin esto, el editor de reglas no ofrece la etiqueta recien creada."""
    import json
    import web.state as _st
    cfg_dir["fuzzy"].write_text(json.dumps({
        "nivel": {"type": "norm", "offset": [0.0, 0.5, 1.0],
                  "labels": {"CRITICO_ALTO": [1.0, 0.0, 0.0]}}}), encoding="utf-8")
    disponibles = _st.etiquetas_disponibles()
    assert "CRITICO_ALTO" in disponibles
    assert "NO-CRITICO_ALTO" in disponibles      # derivada, la genera el nucleo
    assert "OK" in disponibles                   # las base no se pierden


def test_pares_de_regla_conserva_la_etiqueta():
    from core.engine.motor import pares_de_regla
    pares = pares_de_regla({"if": [{"AND": [["nivel", "OK"], ["torque", "HIGH"]]}],
                            "fuerza": ["nivel", "LOW"]})
    assert pares == {("nivel", "OK"), ("torque", "HIGH"), ("nivel", "LOW")}


# ===============================================================
# Defuzzy: eje del belief acotado y ordenado, pasos sin tope
# ===============================================================

def test_belief_axis_debe_ir_de_menor_a_mayor():
    import web.api.config as cfgmod
    _, err = cfgmod._normalizar_defuzzy_payload({
        "sp_vel_bomba": {"belief_axis": [0.0, 0.8, 0.5],
                         "steps_por_accion": {"SUBIR": [0.0, 1.0, 2.0]}}})
    assert err is not None and "menor a mayor" in err


@pytest.mark.parametrize("axis", [[0.0, 1.5], [-0.2, 1.0]])
def test_belief_axis_esta_acotado_a_cero_uno(axis):
    import web.api.config as cfgmod
    _, err = cfgmod._normalizar_defuzzy_payload({
        "sp_vel_bomba": {"belief_axis": axis,
                         "steps_por_accion": {"SUBIR": [0.0, 1.0]}}})
    assert err is not None and "0.0 a 1.0" in err


def test_los_pasos_de_una_accion_no_tienen_tope():
    """Estan en unidades del SP: pueden ser negativos o mucho mayores que 1."""
    import web.api.config as cfgmod
    norm, err = cfgmod._normalizar_defuzzy_payload({
        "sp_vel_bomba": {"belief_axis": [0.0, 0.5, 1.0],
                         "steps_por_accion": {"BAJAR": [-0.5, -12.0, -250.0],
                                              "SUBIR": [0.0, 40.0, 1500.0]}}})
    assert err is None, err
    assert norm["sp_vel_bomba"]["steps_por_accion"]["BAJAR"] == [-0.5, -12.0, -250.0]
    assert norm["sp_vel_bomba"]["steps_por_accion"]["SUBIR"][-1] == 1500.0


def test_enlaces_defuzzy_mapea_fuzzy_regla_accion_sp(cfg_dir, monkeypatch, tmp_path):
    """La pagina tiene que poder mostrar que fuzzys terminan moviendo el SP."""
    import json
    import web.state as _st
    import web.api.config as cfgmod

    dfz = tmp_path / "defuzzy.json"
    monkeypatch.setattr(_st, "DEFUZZY_JSON", str(dfz))
    monkeypatch.setattr(cfgmod, "DEFUZZY_JSON", str(dfz))
    dfz.write_text(json.dumps({
        "sp_vel_bomba": {"belief_axis": [0.0, 1.0],
                         "steps_por_accion": {"SUBIR_VEL": [0.0, 5.0]}}}), encoding="utf-8")
    cfg_dir["reglas"].write_text(json.dumps([
        {"id": "R1", "bloque": "critico",
         "if": [["nivel_hopper", "HIGH"], ["torque", "OK"]],
         "then": ["SUBIR_VEL"]},
        {"id": "R2", "bloque": "critico",
         "if": [["densidad", "LOW"]], "then": ["OTRA_ACCION"]}]),
        encoding="utf-8")

    enl = cfgmod.enlaces_defuzzy()
    assert [r["id"] for r in enl["sp_vel_bomba"]["reglas"]] == ["R1"]
    assert enl["sp_vel_bomba"]["fuzzys"] == ["nivel_hopper", "torque"]
    # R2 no toca esta familia: su accion no esta en la tabla.
    assert all(r["id"] != "R2" for r in enl["sp_vel_bomba"]["reglas"])
