# -*- coding: utf-8 -*-
"""Blueprint bp_se — Alerts, SE Engine, Entrada de datos, Simulación.

Rutas:
  GET                  /api/alerts
  POST                 /api/alerts/<alert_id>/resolve
  POST                 /api/alerts/clear
  GET                  /api/se/status
  GET/PUT              /api/se/piso
  POST                 /api/se/start
  POST                 /api/se/stop
  GET                  /api/entrada
  GET                  /api/entrada/history
  GET                  /api/entrada/escalas
  POST                 /api/simulacion
  POST                 /api/simulacion/start
  GET                  /api/simulacion/next
  POST                 /api/simulacion/reset

IT-7: extraído de app.py.
"""
from __future__ import annotations

import time
import traceback

from flask import Blueprint, jsonify, request

from config import SETPOINT_KEYS, VARIABLES_PROCESO, COLUMNAS_ENTRADA
from web.state import (
    AlertCollector,
    ActivityLogCollector,
    _alerts,
    _activity_log,
    _se_engine,
    _load_tags,
    _read_kepserver_tags_batch,
    _get_tag_history,
    _sim_state,
    _definiciones_lista_a_dict,
    _get_trazas,
    grabador_start, grabador_stop, grabador_estado, grabador_historial,
    GrabadorLimiteActivosError,
    sincronizar_alerta_licencia,
    cortes_motor,
    generacion_motor,
    cargar_motor_cfg,
)

bp_se = Blueprint("se", __name__)


# ============================================================
# API — Alertas
# ============================================================

@bp_se.route("/api/alerts", methods=["GET"])
def api_alerts():
    # Sin licencia la alerta tiene que estar SIEMPRE, aunque el motor este
    # parado o el operador la haya marcado resuelta: se re-sincroniza en cada
    # consulta (la barra de alertas pregunta cada 5 s).
    try:
        sincronizar_alerta_licencia()
    except Exception:                                   # noqa: BLE001
        pass
    show = request.args.get("show", "active")
    if show == "all":
        return jsonify({"alerts": _alerts.get_all(), "categories": AlertCollector.CATEGORIES})
    return jsonify({"alerts": _alerts.get_active(), "categories": AlertCollector.CATEGORIES})


@bp_se.route("/api/alerts/<int:alert_id>/resolve", methods=["POST"])
def api_resolve_alert(alert_id: int):
    ok = _alerts.resolve(alert_id)
    return jsonify({"ok": ok})


@bp_se.route("/api/alerts/clear", methods=["POST"])
def api_clear_alerts():
    _alerts.clear_resolved()
    return jsonify({"ok": True})


# ============================================================
# API — Log de actividad de configuracion (solo observabilidad)
# ============================================================

@bp_se.route("/api/activity-log", methods=["GET"])
def api_activity_log():
    kind = request.args.get("kind") or None
    scope = request.args.get("scope", "active")
    if scope == "history":
        return jsonify({
            "entries": _activity_log.get_history(kind),
            "kinds": ActivityLogCollector.KINDS,
        })
    return jsonify({
        "entries": _activity_log.get_active(),
        "kinds": ActivityLogCollector.KINDS,
    })


@bp_se.route("/api/activity-log", methods=["POST"])
def api_activity_log_post():
    body = request.get_json(force=True) or {}
    action = body.get("action", "")
    page = str(body.get("page", ""))
    page_label = str(body.get("page_label", page or "Sistema"))
    message = str(body.get("message", ""))
    detail = str(body.get("detail", ""))

    if action == "unsaved":
        _activity_log.mark_unsaved(page, page_label, message, detail)
    elif action == "clear_unsaved":
        _activity_log.clear_unsaved(page)
    elif action == "saved":
        _activity_log.log_saved(page, page_label, message, detail)
    elif action == "restart":
        _activity_log.log_restart_needed(page, page_label, message, detail)
    elif action == "error":
        _activity_log.log_error(page, page_label, message or "Error", detail)
    elif action == "info":
        _activity_log.log_info(message, detail, page, page_label)
    else:
        return jsonify({"ok": False, "error": "action invalida"}), 400
    return jsonify({"ok": True})


@bp_se.route("/api/activity-log/<int:entry_id>/dismiss", methods=["POST"])
def api_activity_log_dismiss(entry_id: int):
    ok = _activity_log.dismiss(entry_id)
    return jsonify({"ok": ok})


# ============================================================
# API — SE Engine
# ============================================================

@bp_se.route("/api/se/status", methods=["GET"])
def api_se_status():
    return jsonify(_se_engine.status())


@bp_se.route("/api/se/piso", methods=["GET"])
def api_se_piso_get():
    """Ritmo del lazo: lo configurado y lo que se esta logrando de verdad.

    `piso_ms` es lo pedido; `periodo_ms` es lo que el motor consigue, que es
    `max(dur_tick_ms, piso_ms)`. Si `dormido_ms` vive en cero, el piso no esta
    limitando nada y bajarlo no cambia el ritmo: manda el tick.
    """
    est = _se_engine.status()
    return jsonify({
        "piso_s":          cargar_motor_cfg()["piso_s"],
        "piso_s_activo":   est.get("piso_s"),
        "piso_ms":         est.get("piso_ms"),
        "periodo_ms":      est.get("periodo_ms"),
        "ticks_por_s":     est.get("ticks_por_s"),
        "dur_tick_ms":     est.get("dur_tick_ms"),
        "dur_tick_max_ms": est.get("dur_tick_max_ms"),
        "dormido_ms":      est.get("dormido_ms"),
        "running":         est.get("running", False),
        "max_s":           _se_engine.PISO_S_MAX,
    })


@bp_se.route("/api/se/piso", methods=["PUT"])
def api_se_piso_put():
    """Cambia el piso. Se aplica EN VIVO: no reinicia ni vacia ventanas."""
    body = request.get_json(force=True) if request.content_length else {}
    body = body or {}
    if "piso_s" in body:
        bruto = body["piso_s"]
    elif "piso_ms" in body:
        try:
            bruto = float(body["piso_ms"]) / 1000.0
        except (TypeError, ValueError):
            return jsonify({"ok": False, "error": "piso_ms invalido."}), 400
    else:
        return jsonify({"ok": False, "error": "Falta piso_s (o piso_ms)."}), 400
    try:
        piso = float(bruto)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "piso_s invalido."}), 400
    if piso < 0 or piso > _se_engine.PISO_S_MAX:
        return jsonify({"ok": False,
                        "error": f"El piso debe estar entre 0 y {_se_engine.PISO_S_MAX} s."}), 400
    res = _se_engine.set_piso(piso)
    _activity_log.log_info(
        "Ritmo del motor actualizado",
        f"piso_s={res['piso_s']} (aplicado en vivo, sin reiniciar el lazo)",
    )
    return jsonify(res)


@bp_se.route("/api/se/start", methods=["POST"])
def api_se_start():
    """Arranca el motor en ciclo libre.

    `piso_s` es el periodo MINIMO entre ticks: el motor vuelve a iterar apenas
    termina de escribir los setpoints, y el piso solo evita saturar CPU y
    KEPserver. `intervalo_s` se sigue aceptando como alias historico, de
    cuando el lazo tenia periodo fijo.
    """
    body = request.get_json(force=True) if request.content_length else {}
    body = body or {}
    if "piso_s" in body:
        piso = float(body["piso_s"])
    elif "intervalo_s" in body:
        piso = float(body["intervalo_s"])
    else:
        # Sin piso explicito manda motor.json, no el default de clase: el front
        # ya no tiene por que saber a que ritmo corre el motor de esta planta.
        piso = cargar_motor_cfg()["piso_s"]
    # Cualquier excepcion inesperada del arranque salia como la pagina HTML de
    # error de Flask, y el front — que hace r.json() — informaba
    # "Unexpected token '<'", ocultando el motivo real. Se traduce a JSON.
    try:
        res = _se_engine.start(piso_s=piso) or {"ok": True, "error": None}
    except Exception as exc:
        import traceback
        detalle = f"{type(exc).__name__}: {exc}"
        _activity_log.log_error(
            "se", "Motor SE",
            "El arranque del motor fallo con una excepcion",
            detalle + "\n" + traceback.format_exc(limit=5),
        )
        return jsonify({"ok": False, "running": False,
                        "error": "Fallo interno al arrancar el motor. " + detalle}), 500
    if not res.get("ok"):
        # Mapeo incompleto: no se arranca. El detalle va al front.
        _activity_log.log_error(
            "se", "Motor SE",
            "No se pudo iniciar el motor",
            str(res.get("error") or ""),
        )
        return jsonify({"ok": False, "running": False, "error": res.get("error")}), 400
    _activity_log.clear_restart()
    _activity_log.log_info(
        "Motor SE iniciado",
        f"piso_s={piso}",
    )
    return jsonify({"ok": True, "running": True})


@bp_se.route("/api/se/restart", methods=["POST"])
def api_se_restart():
    """Aplica la configuracion nueva sin soltar el lazo ni vaciar las ventanas.

    Existe como UN endpoint y no como stop+start desde el navegador por dos
    motivos. El primero es que entre las dos llamadas hay un viaje de red: con
    dos pestanas abiertas, o con una recarga a destiempo, se podian solapar un
    stop y un start de rondas distintas. El segundo es que el estado que hay
    que conservar (buffers de pendientes, reloj, objetivo interno de los SP)
    solo existe dentro del proceso: no se puede transportar por HTTP.

    `caliente=false` fuerza el reinicio clasico — suelta ENABLE_EXT y arranca
    con todas las ventanas vacias.
    """
    body = request.get_json(force=True) if request.content_length else {}
    body = body or {}
    caliente = bool(body.get("caliente", True))
    piso = None
    if "piso_s" in body:
        try:
            piso = float(body["piso_s"])
        except (TypeError, ValueError):
            piso = None
    try:
        res = _se_engine.reiniciar(caliente=caliente, piso_s=piso) or {}
    except Exception as exc:
        detalle = f"{type(exc).__name__}: {exc}"
        _activity_log.log_error(
            "se", "Motor SE",
            "El reinicio del motor fallo con una excepcion",
            detalle + "\n" + traceback.format_exc(limit=5),
        )
        return jsonify({"ok": False, "running": _se_engine._running,
                        "error": "Fallo interno al reiniciar el motor. " + detalle}), 500
    if not res.get("ok"):
        _activity_log.log_error(
            "se", "Motor SE", "No se pudo reiniciar el motor",
            str(res.get("error") or ""),
        )
        return jsonify({"ok": False, "running": _se_engine._running,
                        "error": res.get("error"),
                        "generacion": res.get("generacion")}), 400
    _activity_log.clear_restart()
    avisos = res.get("avisos") or []
    _activity_log.log_info(
        "Configuracion aplicada" + ("" if res.get("caliente") else " (reinicio frio)"),
        "\n".join(avisos) if avisos else
        ("El motor se reinicio conservando el lazo y las ventanas."
         if res.get("caliente") else "El motor se reinicio desde cero."),
    )
    return jsonify({"ok": True, "running": _se_engine._running,
                    "caliente": bool(res.get("caliente")),
                    "generacion": res.get("generacion"),
                    "avisos": avisos})


@bp_se.route("/api/se/auto-aplicar", methods=["GET"])
def api_se_auto_aplicar_get():
    """Estado del auto-aplicar: interruptor, si hay cambios sin aplicar y el
    resultado del ultimo reinicio automatico (con sus avisos)."""
    from web.state import _auto_aplicador
    return jsonify(_auto_aplicador.estado())


@bp_se.route("/api/se/auto-aplicar", methods=["PUT"])
def api_se_auto_aplicar_put():
    """Enciende o apaga el auto-aplicar. Es UNO para todo el sistema (motor.json),
    no uno por navegador."""
    from web.state import _auto_aplicador, guardar_auto_aplicar
    body = request.get_json(force=True, silent=True) or {}
    if "enabled" not in body:
        return jsonify({"ok": False, "error": "Falta 'enabled'."}), 400
    guardar_auto_aplicar(bool(body["enabled"]))
    return jsonify({"ok": True, **_auto_aplicador.estado()})


@bp_se.route("/api/se/reinicios", methods=["GET"])
def api_se_reinicios():
    """Tramos en que el motor estuvo abajo, para pintarlos sobre el trending.

    Lo consume el Explorador de Series, que corre en otra pestana y no tiene
    forma de enterarse de un reinicio disparado desde el panel. Sin esto, una
    linea plana no distingue 'el proceso esta quieto' de 'el SE estuvo caido'.
    """
    def _num(nombre):
        v = request.args.get(nombre)
        if v in (None, ""):
            return None
        try:
            return float(v)
        except ValueError:
            return None

    cortes = cortes_motor(_num("from_ms"), _num("to_ms"))
    return jsonify({
        "cortes": cortes,
        "generacion": generacion_motor(),
        "running": _se_engine._running,
        "ahora_ms": time.time() * 1000.0,
    })


@bp_se.route("/api/se/trace", methods=["GET"])
def api_se_trace():
    """Traza del pipeline: que paso en cada etapa del ultimo (o ultimos N) ticks.

    Query params:
      - n: cuantos ticks devolver (por defecto 1, el mas reciente)
    """
    try:
        n = int(request.args.get("n", 1))
    except ValueError:
        n = 1
    trazas = _get_trazas(n)
    estado = _se_engine.status()
    return jsonify({
        "trazas": trazas,
        "running": estado.get("running", False),
        # Cambia en cada arranque: la Traza la compara con la que vio antes
        # para saber que el motor se reinicio y limpiar lo que quedo en
        # pantalla del motor anterior.
        "generacion": estado.get("generacion", 0),
        "disponibles": len(_get_trazas(0)),
        # El anillo de trazas guarda pocos segundos en ciclo libre; el
        # historial de disparos sobrevive y es lo que permite ver que una
        # regla con wait largo si esta actuando.
        "ultimos_disparos": estado.get("ultimos_disparos", []),
        # Lo unico que sale del SE hacia la planta. Sobrevive a los ticks: con
        # write-on-change la mayoria no escribe nada, y la traza sola no
        # responde "que le mando el experto al DCS en la ultima hora".
        "historial_escrituras": estado.get("historial_escrituras", []),
    })


# ============================================================
# API — Grabadores por regla
#
# Seguir UNA regla durante minutos: la traza es un anillo de 60 ticks y no
# alcanza para ver por que una regla no actua. Se pueden grabar varias reglas
# a la vez; la pagina de historial muestra una.
# ============================================================

@bp_se.route("/api/se/grabador", methods=["GET"])
def api_grabador_estado():
    return jsonify(grabador_estado(request.args.get("regla")))


@bp_se.route("/api/se/grabador/<path:regla_id>/start", methods=["POST"])
def api_grabador_start(regla_id: str):
    """Arranca la grabacion. Vacia lo anterior: 'desde que pulso el boton'."""
    try:
        return jsonify(grabador_start(regla_id))
    except GrabadorLimiteActivosError as e:
        return jsonify({**grabador_estado(), "ok": False, "error": str(e)}), 409


@bp_se.route("/api/se/grabador/<path:regla_id>/stop", methods=["POST"])
def api_grabador_stop(regla_id: str):
    """Detiene la grabacion; lo grabado se conserva para poder mirarlo."""
    return jsonify(grabador_stop(regla_id))


@bp_se.route("/api/se/grabador/<path:regla_id>", methods=["GET"])
def api_grabador_historial(regla_id: str):
    return jsonify(grabador_historial(regla_id))


@bp_se.route("/api/se/stop", methods=["POST"])
def api_se_stop():
    res = _se_engine.stop() or {"ok": True, "error": None}
    if res.get("ok"):
        _activity_log.log_info("Motor SE detenido")
    elif res.get("error"):
        _activity_log.log_error("se", "Motor SE", "Error al detener el motor",
                                str(res.get("error")))
    return jsonify({"ok": bool(res.get("ok")),
                    "error": res.get("error"),
                    "running": _se_engine._running})


# ============================================================
# API — Entrada de Datos (all tags + history)
# ============================================================

@bp_se.route("/api/entrada", methods=["GET"])
def api_entrada():
    store = _load_tags()
    tags = store.get("tags", [])
    enabled_names = [t["name"] for t in tags if t.get("enabled", True)]

    live = _read_kepserver_tags_batch(enabled_names) if enabled_names else {}
    hist = _get_tag_history()

    result = []
    for t in tags:
        name = t["name"]
        is_enabled = t.get("enabled", True)
        info = live.get(name, {}) if is_enabled else {}
        # El grupo sale de la categoria elegida a mano, NO del prefijo del
        # nombre. Deducirlo de `RETO.PV.` / `RETO.SP.` / ... solo funcionaba con
        # la nomenclatura del prototipo: con nombres de planta (PCS7.OS01.*)
        # ningun tag matcheaba y los 27 caian en "other", asi que los filtros
        # PV / SP / LIM del Explorador de Series no filtraban nada.
        categoria = (t.get("categoria") or "").strip().lower()
        group = categoria if categoria in ("pv", "cruda", "lim", "sp") else "other"
        direction = "output" if group == "sp" else "input"
        result.append({
            "id":          t["id"],
            "name":        name,
            "value":       info.get("value"),
            "exists":      info.get("exists", False),
            "direction":   direction,
            "group":       group,
            "enabled":     is_enabled,
            "processes":   t.get("processes", ["espesadores"]),
            "pseudonimo":  t.get("pseudonimo", ""),
            "instrumento": t.get("instrumento", ""),
            "unidad_ing":  t.get("unidad_ing", ""),
            "equipo":      t.get("equipo", ""),
            "history":     hist.get(name, []),
        })
    return jsonify(result)


@bp_se.route("/api/entrada/history", methods=["GET"])
def api_entrada_history():
    return jsonify(_get_tag_history())


@bp_se.route("/api/se/grafico/anotaciones", methods=["GET"])
def api_grafico_anotaciones():
    """Dominio, pendiente y aceleracion POR TAG, de la ultima traza del pipeline.

    El Explorador de Series habla en tags (PCS7.OS01.Hopper_Nivel_PV_A) y el
    pipeline en variables (hopper_nvl_pv_a). El puente es el mismo mapeo
    rol<->tag que usa el motor, asi que lo que se muestra en el grafico es
    exactamente lo que la traza dice — no una segunda cuenta hecha aparte que
    podria discrepar de la que toman las reglas.

    La pendiente y la aceleracion de una variable se buscan entre las filas
    marcadas como tales cuya `fuente` es esa variable. Sin motor corriendo no
    hay traza: se devuelve running=false y el grafico lo dice en vez de
    inventar.

    Si hay VARIAS pendientes (o aceleraciones) sobre la misma variable se
    reporta la primera. Es deliberado: el tooltip tiene lugar para un numero,
    y elegir en silencio "la mas corta" o "la mas larga" seria una regla
    invisible. Quien necesita comparar ventanas tiene la traza y la pagina de
    Aceleracion, que las muestran todas.
    """
    from web.state import construir_mapeo, anotaciones_por_tag

    trazas = _get_trazas(1)
    tz = (trazas[-1] if trazas else {}) or {}
    try:
        running = bool(_se_engine.status().get("running"))
    except Exception:
        running = False
    por_tag = anotaciones_por_tag(tz, construir_mapeo())
    return jsonify({"running": running, "ts": tz.get("ts"), "por_tag": por_tag})


@bp_se.route("/api/se/grafico/anotaciones/historial", methods=["GET"])
def api_grafico_anotaciones_historial():
    """Dominio, pendiente y aceleracion POR INSTANTE, para el tooltip.

    Query: tags (csv), from_ms, to_ms. Una muestra por segundo mientras el
    motor corrio; donde no corrio no hay muestras (y el grafico no inventa).
    """
    from web.state import historial_anotaciones
    tags = [t.strip() for t in request.args.get("tags", "").split(",") if t.strip()]
    try:
        from_ms = float(request.args.get("from_ms", 0))
        to_ms = float(request.args.get("to_ms", time.time() * 1000.0))
    except ValueError:
        return jsonify({"error": "from_ms / to_ms deben ser numericos."}), 400
    return jsonify({"puntos": historial_anotaciones(from_ms, to_ms, tags or None)})


@bp_se.route("/api/entrada/escalas", methods=["GET"])
def api_entrada_escalas():
    """Escala de ingenieria (lmin/lmax) de cada tag graficable.

    La usa el Explorador de Series para normalizar cada serie contra SU banda
    de operacion en vez de contra el min/max de lo que se ve. La diferencia no
    es cosmetica: con min/max de ventana, una PV quieta se estira hasta llenar
    la pantalla y parece estar oscilando; contra sus limites, un nivel al 70%
    de su banda se dibuja al 70% y se puede comparar con una velocidad al 95%
    de la suya — que es la pregunta real ("quien esta por saturar").

    El cableado es el mismo que usa el fuzzy (`bindings_limites`), asi que la
    escala del grafico y la que decide las pertenencias no pueden divergir. Se
    prefiere el tag leido en vivo y se cae al respaldo numerico solo si ese
    bound no tiene tag cableado, con el mismo criterio que el motor.
    """
    from web.state import (construir_mapeo, bindings_limites, limites_num,
                           valor_utilizable)

    mapeo = construir_mapeo()
    var_por_tag: dict[str, str] = {}
    for tag, var in (mapeo.get("tag_to_pv") or {}).items():
        var_por_tag[tag] = var
    for var, tag in (mapeo.get("sp_to_tag") or {}).items():
        var_por_tag.setdefault(tag, var)

    binds = bindings_limites()
    nums = limites_num()
    variables = set(var_por_tag.values())
    tags_lim = sorted({t for (v, _b), t in binds.items() if v in variables})
    live = _read_kepserver_tags_batch(tags_lim) if tags_lim else {}

    out = {}
    for tag, var in var_por_tag.items():
        bounds, origen = {}, {}
        for bound in ("lmin", "lmax"):
            tag_lim = binds.get((var, bound))
            if tag_lim:
                info = live.get(tag_lim, {}) or {}
                if valor_utilizable(info):
                    try:
                        bounds[bound] = float(info["value"])
                        origen[bound] = tag_lim
                        continue
                    except (TypeError, ValueError):
                        pass
                # Bound con tag ilegible: NO cae al respaldo, mismo criterio
                # que `_resolver_limites_sp`. Sin escala confiable, el grafico
                # usa min/max de la ventana y lo dice.
                continue
            respaldo = (nums.get(var) or {})
            if bound in respaldo:
                try:
                    bounds[bound] = float(respaldo[bound])
                    origen[bound] = "respaldo numerico"
                except (TypeError, ValueError):
                    pass
        if "lmin" in bounds and "lmax" in bounds and bounds["lmax"] > bounds["lmin"]:
            out[tag] = {"var": var, "lmin": bounds["lmin"], "lmax": bounds["lmax"],
                        "origen": origen}
    return jsonify(out)


# ============================================================
# Simulación — helper compartido
# ============================================================

def _rango_por_rol(mapeo: dict, ranges: dict) -> dict:
    """Rangos del generador de tags, reindexados por ROL del SE.

    El generador guarda min/max/ruido por TAG (asi los edita el operador en
    Tags KEPserver); el pipeline razona en roles del contrato. El puente es el
    mapeo tag->rol que ya usa el motor en vivo.
    """
    out = {}
    for tag, rol in (mapeo.get("tag_to_pv") or {}).items():
        if tag in ranges:
            out[rol] = ranges[tag]
    for tag, rol in (mapeo.get("tag_to_cruda") or {}).items():
        if tag in ranges:
            out[rol] = ranges[tag]
    for tag, pares in (mapeo.get("tag_to_lim") or {}).items():
        if tag in ranges:
            for var, bound in pares:
                out[f"{var}_{bound}"] = ranges[tag]
    for rol, tag in (mapeo.get("sp_to_tag") or {}).items():
        if tag in ranges:
            out[rol] = ranges[tag]
    return out


def _serie_tres_fases(n: int, n_ciclo: int, vmin: float, vmax: float,
                      noise: float, rng) -> list[float]:
    """Misma curva 3-fases del generador en vivo, pero con ruido reproducible.

    El generador usa `random.gauss`; aca el ruido sale de un RNG sembrado con
    `seed` para que dos corridas con la misma semilla den el mismo resultado,
    que es lo que hace comparable una simulacion.
    """
    vmin, vmax = float(vmin), float(vmax)
    n_ciclo = max(1, int(n_ciclo))
    vals = []
    for tick in range(n):
        pos = (tick % n_ciclo) / n_ciclo
        if pos < 0.35:
            base = vmin + (vmax - vmin) * 0.2
        elif pos < 0.70:
            base = vmin + (vmax - vmin) * (0.2 + 0.7 * (pos - 0.35) / 0.35)
        else:
            base = vmin + (vmax - vmin) * (0.9 - 0.5 * (pos - 0.70) / 0.30)
        val = base + (float(rng.normal(0.0, float(noise))) if noise else 0.0)
        vals.append(max(vmin, min(vmax, val)))
    return vals


def _datos_desde_generador(n_muestras: int, dt_s: float, seed: int) -> tuple:
    """DataFrame sintetico armado desde el CONTRATO y los rangos del generador.

    Antes esto lo hacia `simulacion.generar_datos_proceso()`, que tiene las
    columnas del espesador original cableadas (torque, bed_level, densidad...).
    Con cualquier otro contrato la simulacion moria con un KeyError del nombre
    de la primera PV — no habia forma de probar reglas de un cliente nuevo.

    Ahora las columnas salen de VARIABLES_PROCESO / crudas / SP del contrato, y
    los valores de los mismos min/max/ruido que el operador ya configuro en
    Tags KEPserver para el generador en vivo. Una sola fuente de verdad.

    Devuelve (df, avisos, setpoints_base).
    """
    import numpy as np
    import pandas as pd
    from config import (VARIABLES_PROCESO, VARIABLES_CRUDAS_REQUERIDAS,
                        SETPOINT_KEYS, LIMITES_SP_CONTRATO)
    from web.state import construir_mapeo, _tag_generator

    if not VARIABLES_PROCESO:
        raise ValueError("El contrato no tiene variables de proceso: "
                         "define al menos una PV en Contrato de Variables.")

    estado = _tag_generator.status()
    ranges = estado.get("ranges") or {}
    n_ciclo = int(estado.get("n_ciclo") or 60)
    rangos = _rango_por_rol(construir_mapeo(), ranges)

    rng = np.random.default_rng(int(seed))
    n = int(n_muestras)
    avisos = []
    cols = {"t_s": np.arange(0, n * float(dt_s), float(dt_s), dtype=float)[:n]}

    def _mm(rol, defecto):
        """min/max/ruido del rol, o un default explicado en los avisos."""
        r = rangos.get(rol)
        if not r:
            avisos.append(f"'{rol}' no tiene rango en el generador de tags: "
                          f"se simula en {defecto[0]}-{defecto[1]}.")
            return defecto[0], defecto[1], defecto[2]
        return float(r.get("min", 0.0)), float(r.get("max", 0.0)), float(r.get("noise", 0.0))

    # --- Limites primero: acotan el rango en el que conviene mover la PV ---
    lim_vals = {}
    for var in VARIABLES_PROCESO:
        for bound, defecto in (("lmin", (0.0, 0.0, 0.0)), ("lmax", (100.0, 100.0, 0.0))):
            rol = f"{var}_{bound}"
            vmin, vmax, _ = _mm(rol, defecto)
            # Un limite es una constante: si min y max difieren, se toma el medio.
            lim_vals[rol] = (vmin + vmax) / 2.0
            cols[rol] = np.full(n, lim_vals[rol], dtype=float)

    # --- PV: la curva 3-fases entre su min y su max ---
    for var in VARIABLES_PROCESO:
        lo, hi = lim_vals[f"{var}_lmin"], lim_vals[f"{var}_lmax"]
        vmin, vmax, noise = _mm(var, (lo, hi if hi > lo else lo + 100.0, 1.0))
        if vmax <= vmin:
            vmax = vmin + 1.0
        cols[var] = np.array(_serie_tres_fases(n, n_ciclo, vmin, vmax, noise, rng))

    for var in VARIABLES_CRUDAS_REQUERIDAS:
        vmin, vmax, noise = _mm(var, (0.0, 100.0, 1.0))
        if vmax <= vmin:
            vmax = vmin + 1.0
        cols[var] = np.array(_serie_tres_fases(n, n_ciclo, vmin, vmax, noise, rng))

    # --- Setpoints: arrancan donde el generador los tiene y los mueve el SE ---
    setpoints_base = {}
    for sp in SETPOINT_KEYS:
        lims = LIMITES_SP_CONTRATO.get(sp) or ()
        defecto = (float(lims[0]), float(lims[1]), 0.0) if len(lims) == 2 else (0.0, 100.0, 0.0)
        vmin, vmax, _ = _mm(sp, defecto)
        setpoints_base[sp] = (vmin + vmax) / 2.0
        cols[sp] = np.full(n, setpoints_base[sp], dtype=float)

    return pd.DataFrame(cols), avisos, setpoints_base


def _ejecutar_simulacion(params: dict) -> dict:
    from runner import (
        correr_prueba_general,
        cargar_reglas_json,
        cargar_filtros_json,
        cargar_defuzzy_json,
        cargar_fuzzy_json,
        cargar_variables_json,
        cargar_permisivos_json,
    )
    from config import (VARIABLES_PROCESO, COLUMNAS_ENTRADA, SETPOINT_KEYS,
                        LIMITES_SP_CONTRATO)
    from core.fuzzy.templates import construir_registry_fuzzy

    n_muestras = int(params.get("n_muestras", 240))
    dt_s       = float(params.get("dt_s", 60.0))
    seed       = int(params.get("seed", 42))

    df_data, avisos, setpoints_base = _datos_desde_generador(n_muestras, dt_s, seed)

    limites_sp = {sp: tuple(LIMITES_SP_CONTRATO[sp]) for sp in SETPOINT_KEYS
                  if sp in LIMITES_SP_CONTRATO}
    faltan_lim = [sp for sp in SETPOINT_KEYS if sp not in limites_sp]
    if faltan_lim:
        raise ValueError("Setpoints sin limites en el contrato (el defuzzy no "
                         "sabria hasta donde moverlos): " + ", ".join(faltan_lim))

    reglas        = cargar_reglas_json()
    config_filtro = cargar_filtros_json()

    # Defuzzy: las tablas vigentes, pasadas explicitamente. Antes esto hacia
    # clear()+update() sobre el dict global de defuzzy_actions — el MISMO que
    # usaba el motor en vivo en otro hilo. Simular cambiaba el comportamiento
    # del SE en produccion, y entre el clear y el update habia una ventana en
    # la que el motor veia la tabla vacia.
    defuzzy_cfg = cargar_defuzzy_json()

    # Fuzzy: se construye el registry igual que el motor en vivo. La version
    # anterior parcheaba FUZZY_MODELOS del espesador exigiendo filas llamadas
    # HIGH/OK/LOW — con etiquetas de nombre libre reventaba con KeyError.
    fuzzy_modelos = construir_registry_fuzzy(cargar_fuzzy_json()) or {}
    sin_fuzzy = [v for v in VARIABLES_PROCESO if v not in fuzzy_modelos]
    if sin_fuzzy:
        avisos.append("PV sin modelo difuso (no se fuzzifican, y las reglas que "
                      "las nombran no pueden disparar): " + ", ".join(sin_fuzzy))

    from runner import cargar_pendientes_json
    vars_cfg         = cargar_variables_json()
    definiciones_cfg = _definiciones_lista_a_dict(vars_cfg.get("definiciones", []))
    permisivos_cfg   = cargar_permisivos_json()

    resultados = correr_prueba_general(
        df_data=df_data,
        reglas=reglas,
        setpoints_base=setpoints_base,
        limites_sp=limites_sp,
        min_belief=0.05,
        verbose=False,
        calcular_vars=True,
        dt_s=dt_s,
        columnas_entrada=COLUMNAS_ENTRADA,
        config_filtro=config_filtro,
        definiciones_calculadas=definiciones_cfg,
        permisivos_config=permisivos_cfg,
        fuzzy_modelos=fuzzy_modelos,
        # Vacio a proposito: PEND_MODELOS era el dict del espesador viejo. Las
        # pendientes de verdad salen de pendientes.json, abajo.
        pend_modelos={},
        pendientes_config=cargar_pendientes_json(),
        variables_proceso=list(VARIABLES_PROCESO),
        defuzzy_por_familia=defuzzy_cfg,
    )
    resultados["avisos"] = avisos
    return resultados


# ============================================================
# API — Simulación (síncrona)
# ============================================================

@bp_se.route("/api/simulacion", methods=["POST"])
def api_simulacion():
    try:
        params = request.get_json(silent=True) or {}
        resultados = _ejecutar_simulacion(params)

        df_res = resultados["resultados"]
        df_ev  = resultados["eventos"]

        sp_final = {}
        if not df_res.empty:
            ultima = df_res.iloc[-1]
            for sp in SETPOINT_KEYS:
                if sp in df_res.columns:
                    sp_final[sp] = round(float(ultima[sp]), 3)

        eventos_list = []
        if not df_ev.empty:
            for _, row in df_ev.iterrows():
                eventos_list.append({
                    "t_s":      round(float(row["t_s"]), 1),
                    "regla_id": str(row["regla_id"]),
                    "bloque":   str(row.get("bloque", "")),
                    "acciones": str(row.get("acciones", "")),
                    "belief":   round(float(row["belief"]), 4),
                })

        activaciones_por_regla = {}
        activaciones_por_bloque = {}
        if not df_ev.empty:
            activaciones_por_regla = {
                str(k): int(v) for k, v in df_ev["regla_id"].value_counts().to_dict().items()
            }
            if "bloque" in df_ev.columns:
                activaciones_por_bloque = {
                    str(k): int(v) for k, v in df_ev["bloque"].value_counts().to_dict().items()
                }

        return jsonify({
            "ok":                      True,
            "muestras":                len(df_res),
            "total_eventos":           len(df_ev),
            "setpoints_finales":       sp_final,
            "activaciones_por_regla":  activaciones_por_regla,
            "activaciones_por_bloque": activaciones_por_bloque,
            "eventos":                 eventos_list[:50],
            # Lo que se simulo con defaults o quedo sin fuzzificar: sin esto,
            # una corrida con 0 eventos parece un problema de las reglas.
            "avisos":                  resultados.get("avisos", []),
        })
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "trace": traceback.format_exc()}), 500


# ============================================================
# API — Simulación streaming
# ============================================================

@bp_se.route("/api/simulacion/start", methods=["POST"])
def api_sim_start():
    try:
        params = request.get_json(silent=True) or {}
        resultados = _ejecutar_simulacion(params)
        _sim_state["df_resultados"] = resultados["resultados"]
        _sim_state["df_eventos"]    = resultados["eventos"]
        _sim_state["cursor"]        = 0
        _sim_state["running"]       = True
        _sim_state["batch_size"]    = int(params.get("batch_size", 5))
        return jsonify({"ok": True, "total": len(resultados["resultados"])})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "trace": traceback.format_exc()}), 500


@bp_se.route("/api/simulacion/next", methods=["GET"])
def api_sim_next():
    if not _sim_state["running"] or _sim_state["df_resultados"] is None:
        return jsonify({"ok": False, "error": "No hay simulacion activa."}), 400

    df     = _sim_state["df_resultados"]
    cursor = _sim_state["cursor"]
    batch  = _sim_state["batch_size"]
    total  = len(df)

    if cursor >= total:
        _sim_state["running"] = False
        return jsonify({"ok": True, "done": True, "points": [], "eventos": [],
                        "cursor": cursor, "total": total})

    end   = min(cursor + batch, total)
    chunk = df.iloc[cursor:end]
    pv_keys = list(VARIABLES_PROCESO)

    points = []
    for _, row in chunk.iterrows():
        pt = {
            "t_s":      round(float(row["t_s"]), 1),
            "t_min":    round(float(row["t_min"]), 2),
            "n_reglas": int(row.get("n_reglas_activadas", 0)),
            "reglas":   str(row.get("reglas_activadas", "")),
        }
        for var in pv_keys:
            if var in df.columns:
                pt[var] = round(float(row[var]), 3)
        for sp in SETPOINT_KEYS:
            if sp in df.columns:
                pt[sp] = round(float(row[sp]), 3)
        points.append(pt)

    df_ev  = _sim_state["df_eventos"]
    ev_list = []
    if df_ev is not None and not df_ev.empty:
        t_start = float(chunk.iloc[0]["t_s"])
        t_end   = float(chunk.iloc[-1]["t_s"])
        mask    = (df_ev["t_s"] >= t_start) & (df_ev["t_s"] <= t_end)
        for _, row in df_ev[mask].iterrows():
            ev_list.append({
                "t_s":      round(float(row["t_s"]), 1),
                "regla_id": str(row["regla_id"]),
                "bloque":   str(row.get("bloque", "")),
                "acciones": str(row.get("acciones", "")),
                "belief":   round(float(row["belief"]), 4),
            })

    _sim_state["cursor"] = end
    return jsonify({"ok": True, "done": False, "points": points, "eventos": ev_list,
                    "cursor": end, "total": total})


@bp_se.route("/api/simulacion/reset", methods=["POST"])
def api_sim_reset():
    _sim_state["cursor"]  = 0
    _sim_state["running"] = _sim_state["df_resultados"] is not None
    return jsonify({"ok": True})
